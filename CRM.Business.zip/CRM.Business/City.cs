﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Business
{
    public class City
    {
        public List<Model.City> GetCityByRegion(int regionID)
        {
            var city = new Model.City();
            return city.GetCityByRegion(regionID);
        }
    }
}
