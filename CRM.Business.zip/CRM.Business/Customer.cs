﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Business
{
    public class Customer
    {
        public List<Model.CustomerGrid> GetCustomerList(Model.UserInformations userInformations, Model.CustomerFilters filters)
        {
            var customer = new Model.Customer();
            return customer.GetForGrid(userInformations, filters);
        }

    }
}
