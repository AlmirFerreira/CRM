﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Business
{
    public class UserSys
    {

        public Model.UserInformations GetUserInformations(string email, string password)
        {
            var userSys = new Model.UserSys();
            return userSys.GetUserInformations(email, password);
        }

        public List<Model.UserSys> GetAll()
        {
            var userSys = new Model.UserSys();
            return userSys.GetAll();
        }

    }
}
