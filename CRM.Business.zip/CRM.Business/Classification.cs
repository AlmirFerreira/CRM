﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Business
{
    public class Classification
    {
        public List<Model.Classification> GetClassificationList()
        {
            var gender = new Model.Classification();
            return gender.GetClassification();
        }
    }
}
