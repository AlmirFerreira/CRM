﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Business
{
    public class Gender
    {

        public List<Model.Gender> GetGenderList()
        {
            var gender = new Model.Gender();
            return gender.GetGender();
        }

    }
}
