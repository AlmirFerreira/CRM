﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Business
{
    public class Region
    {
        public List<Model.Region> GetRegionList()
        {
            var region = new Model.Region();
            return region.GetRegion();
        }
    }
}
