﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Model
{
    public class UserSys
    {
        #region Properties
        public int Id { get; set; }
        public string Login { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int UserRoleId { get; set; }
        #endregion

        #region Methods
        public UserInformations GetUserInformations(string email, string password)
        {

            var userInfo = new UserInformations();

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Almir\source\repos\CRM\Database.mdf;Integrated Security=True;Connect Timeout=30"))
            {

                try
                {
                    StringBuilder sql = new StringBuilder();
                    sql.AppendLine(" SELECT u.Id, u.Email, r.IsAdmin ");
                    sql.AppendLine(" FROM UserSys u WITH(NOLOCK) ");
                    sql.AppendLine(" INNER JOIN UserRole r WITH(NOLOCK) ON r.Id = u.UserRoleId ");
                    sql.AppendLine(" WHERE ");
                    sql.AppendFormat(" u.Email = '{0}' ", email);
                    sql.AppendFormat(" AND u.Password = '{0}' ", password);


                    SqlCommand sqlCommand = new SqlCommand(sql.ToString(), conn);
                    conn.Open();

                    var objDataReader = sqlCommand.ExecuteReader();
                    if (objDataReader.HasRows)
                    {
                        userInfo = OrMapping(objDataReader);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

            }

            return userInfo;

        } 

        public List<UserSys> GetAll()
        {
            var userSysList = new List<UserSys>();

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Almir\source\repos\CRM\Database.mdf;Integrated Security=True;Connect Timeout=30"))
            {

                try
                {
                    StringBuilder sql = new StringBuilder();
                    sql.AppendLine(" SELECT Id, Login FROM UserSys ");

                    SqlCommand sqlCommand = new SqlCommand(sql.ToString(), conn);
                    conn.Open();

                    var objDataReader = sqlCommand.ExecuteReader();
                    if (objDataReader.HasRows)
                    {
                        userSysList = OrMappingBasic(objDataReader);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

            }

            return userSysList;
        }
        #endregion

        #region Mapping
        private static UserInformations OrMapping(SqlDataReader reader)
        {
            var customer = new UserInformations();
            if (reader.Read())
            {
                customer.Id = Convert.ToInt32(reader["Id"]);
                customer.Email = reader["Email"].ToString();
                customer.IsAdmin = Convert.ToBoolean(reader["IsAdmin"]);
            }

            return customer;
        }


        private static List<UserSys> OrMappingBasic(SqlDataReader reader)
        {
            var userSysList = new List<UserSys>();
            while (reader.Read())
            {
                var userSys = new UserSys()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Login = reader["Login"].ToString()
                };

                userSysList.Add(userSys);

            }

            return userSysList;
        }
        #endregion
    }

    public class UserInformations
    {
        #region Properties
        public int Id { get; set; }
        public string Email { get; set; }
        public bool IsAdmin { get; set; } 
        #endregion
    }
}
