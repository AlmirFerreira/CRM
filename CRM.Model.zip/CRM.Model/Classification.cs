﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Model
{
    public class Classification
    {
        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        #endregion

        #region Methods
        public List<Classification> GetClassification()
        {
            var genderList = new List<Classification>();

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Almir\source\repos\CRM\Database.mdf;Integrated Security=True;Connect Timeout=30"))
            {

                try
                {
                    StringBuilder sql = new StringBuilder();
                    sql.AppendLine(" SELECT Id, Name FROM Classification ");

                    SqlCommand sqlCommand = new SqlCommand(sql.ToString(), conn);
                    conn.Open();

                    var objDataReader = sqlCommand.ExecuteReader();
                    if (objDataReader.HasRows)
                    {
                        genderList = OrMapping(objDataReader);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

            }

            return genderList;

        }
        #endregion

        #region Mapping
        private static List<Classification> OrMapping(SqlDataReader reader)
        {
            var classificationList = new List<Classification>();
            while (reader.Read())
            {
                var customer = new Classification()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Name = reader["Name"].ToString()
                };

                classificationList.Add(customer);

            }

            return classificationList;
        }
        #endregion
    }
}
