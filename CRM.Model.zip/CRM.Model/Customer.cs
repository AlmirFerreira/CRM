﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Model
{
    public class Customer
    {

        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public int GenderId { get; set; }
        public int CityId { get; set; }
        public int RegionId { get; set; }
        public DateTime LastPurchase { get; set; }
        public int ClassificationId { get; set; }
        public int UserId { get; set; }
        #endregion

        #region Methods
        public List<CustomerGrid> GetForGrid(UserInformations userInformations, CustomerFilters filters)
        {
            var listReturn = new List<CustomerGrid>();

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Almir\source\repos\CRM\Database.mdf;Integrated Security=True;Connect Timeout=30"))
            {

                try
                {
                    StringBuilder sql = new StringBuilder();
                    sql.AppendLine(" SELECT ");
                    sql.AppendLine("    c.Id, ");
                    sql.AppendLine("    classif.Name AS Classification, ");
                    sql.AppendLine("    c.Name, ");
                    sql.AppendLine("    c.Phone,  ");
                    sql.AppendLine("    gend.Name AS Gender, ");
                    sql.AppendLine("    city.Name AS City, ");
                    sql.AppendLine("    reg.Name AS Region, ");
                    sql.AppendLine("    c.LastPurchase, ");
                    sql.AppendLine("    u.Login AS Seller ");


                    sql.AppendLine(" FROM Customer c WITH(NOLOCK) ");
                    sql.AppendLine(" INNER JOIN Classification classif WITH(NOLOCK) ");
                    sql.AppendLine("    ON classif.Id = c.ClassificationId ");
                    sql.AppendLine(" INNER JOIN UserSys u WITH(NOLOCK) ");
                    sql.AppendLine("    ON u.Id = c.UserID ");
                    sql.AppendLine(" INNER JOIN City city WITH(NOLOCK) ");
                    sql.AppendLine("    ON city.Id = c.CityId ");
                    sql.AppendLine(" INNER JOIN Region reg WITH(NOLOCK) ");
                    sql.AppendLine("    ON reg.Id = c.RegionId ");
                    sql.AppendLine(" INNER JOIN Gender gend WITH(NOLOCK) ");
                    sql.AppendLine("    ON gend.Id = c.GenderId ");
                    sql.AppendLine(" WHERE 1 = 1 ");

                    if (!userInformations.IsAdmin)
                    {
                        sql.AppendFormat(" AND c.UserId = {0} ", userInformations.Id);
                    }

                    if (filters.SellerId > 0)
                    {
                        sql.AppendFormat(" AND c.UserId = {0} ", filters.SellerId);
                    }

                    if (filters.GenderId > 0)
                    {
                        sql.AppendFormat(" AND gend.Id = {0} ", filters.GenderId);
                    }

                    if (filters.CityId > 0)
                    {
                        sql.AppendFormat(" AND city.Id = {0} ", filters.CityId);
                    }

                    if (filters.RegionId > 0)
                    {
                        sql.AppendFormat(" AND reg.Id = {0} ", filters.RegionId);
                    }

                    if (filters.LastPurchaseBegin != DateTime.MinValue && filters.LastPurchaseEnd != DateTime.MinValue)
                    {
                        sql.AppendFormat(" AND c.LastPurchase BETWEEN '{0}' AND '{1}' ", filters.LastPurchaseBegin.ToString("yyyy-MM-dd"), filters.LastPurchaseEnd.ToString("yyyy-MM-dd"));
                    }

                    if (filters.ClassificationId > 0)
                    {
                        sql.AppendFormat(" AND classif.Id = {0} ", filters.ClassificationId);
                    }

                    SqlCommand sqlCommand = new SqlCommand(sql.ToString(), conn);
                    conn.Open();

                    var objDataReader = sqlCommand.ExecuteReader();
                    if (objDataReader.HasRows)
                    {
                        listReturn = OrMapping(objDataReader);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

            }

            return listReturn;

        }
        #endregion

        #region Mapping
        private static List<CustomerGrid> OrMapping(SqlDataReader reader)
        {
            var customerList = new List<CustomerGrid>();
            while (reader.Read())
            {
                var customer = new CustomerGrid()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Name = reader["Name"].ToString(),
                    Phone = reader["Phone"].ToString(),
                    Gender = reader["Gender"].ToString(),
                    City = reader["City"].ToString(),
                    Region = reader["Region"].ToString(),
                    LastPurchase = Convert.ToDateTime(reader["LastPurchase"]),
                    Classification = reader["Classification"].ToString(),
                    Seller = reader["Seller"].ToString()
                };

                customerList.Add(customer);

            }

            return customerList;
        }
        #endregion

    }

    public class CustomerFilters
    {
        #region Properties
        public string Name { get; set; }
        public int GenderId { get; set; }
        public int CityId { get; set; }
        public int RegionId { get; set; }
        public DateTime LastPurchaseBegin { get; set; }
        public DateTime LastPurchaseEnd { get; set; }
        public int ClassificationId { get; set; }
        public int SellerId { get; set; } 
        #endregion
    }

    public class CustomerGrid
    {
        #region Properties
        public int Id { get; set; }
        public string Classification { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Gender { get; set; }
        public string City { get; set; }
        public string Region { get; set; }
        public DateTime LastPurchase { get; set; }
        public string Seller { get; set; }
        #endregion
    }
}
