﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Model
{
    public class Region
    {
        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        #endregion

        #region Methods
        public List<Region> GetRegion()
        {
            var genderList = new List<Region>();

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Almir\source\repos\CRM\Database.mdf;Integrated Security=True;Connect Timeout=30"))
            {

                try
                {
                    StringBuilder sql = new StringBuilder();
                    sql.AppendLine(" SELECT Id, Name FROM Region ");

                    SqlCommand sqlCommand = new SqlCommand(sql.ToString(), conn);
                    conn.Open();

                    var objDataReader = sqlCommand.ExecuteReader();
                    if (objDataReader.HasRows)
                    {
                        genderList = OrMapping(objDataReader);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

            }

            return genderList;

        }
        #endregion

        #region Mapping
        private static List<Region> OrMapping(SqlDataReader reader)
        {
            var genderList = new List<Region>();
            while (reader.Read())
            {
                var customer = new Region()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Name = reader["Name"].ToString()
                };

                genderList.Add(customer);

            }

            return genderList;
        }
        #endregion
    }
}
