﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Model
{
    public class City
    {
        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        #endregion

        #region Methods
        public List<City> GetCityByRegion(int regionID)
        {
            var cityList = new List<City>();

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Almir\source\repos\CRM\Database.mdf;Integrated Security=True;Connect Timeout=30"))
            {

                try
                {
                    StringBuilder sql = new StringBuilder();
                    sql.AppendFormat(" SELECT Id, Name FROM City WHERE RegionId = {0} ", regionID);

                    SqlCommand sqlCommand = new SqlCommand(sql.ToString(), conn);
                    conn.Open();

                    var objDataReader = sqlCommand.ExecuteReader();
                    if (objDataReader.HasRows)
                    {
                        cityList = OrMapping(objDataReader);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    conn.Close();
                }

            }

            return cityList;

        }
        #endregion

        #region Mapping
        private static List<City> OrMapping(SqlDataReader reader)
        {
            var cityList = new List<City>();
            while (reader.Read())
            {
                var customer = new City()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Name = reader["Name"].ToString()
                };

                cityList.Add(customer);

            }

            return cityList;
        }
        #endregion
    }
}
